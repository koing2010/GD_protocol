/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[22];
    char stringdata0[247];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 27), // "on_OpenSerialButton_clicked"
QT_MOC_LITERAL(2, 39, 0), // ""
QT_MOC_LITERAL(3, 40, 8), // "ReadData"
QT_MOC_LITERAL(4, 49, 16), // "ConvertChartoHex"
QT_MOC_LITERAL(5, 66, 2), // "ch"
QT_MOC_LITERAL(6, 69, 16), // "ConvertHexToChar"
QT_MOC_LITERAL(7, 86, 10), // "ParseFrame"
QT_MOC_LITERAL(8, 97, 11), // "QByteArray&"
QT_MOC_LITERAL(9, 109, 3), // "msg"
QT_MOC_LITERAL(10, 113, 14), // "SenRequestData"
QT_MOC_LITERAL(11, 128, 3), // "Cmd"
QT_MOC_LITERAL(12, 132, 4), // "Data"
QT_MOC_LITERAL(13, 137, 6), // "CalFCS"
QT_MOC_LITERAL(14, 144, 4), // "data"
QT_MOC_LITERAL(15, 149, 11), // "StringToHex"
QT_MOC_LITERAL(16, 161, 3), // "str"
QT_MOC_LITERAL(17, 165, 8), // "senddata"
QT_MOC_LITERAL(18, 174, 21), // "on_FileButton_clicked"
QT_MOC_LITERAL(19, 196, 23), // "on_NewPortBox_activated"
QT_MOC_LITERAL(20, 220, 4), // "arg1"
QT_MOC_LITERAL(21, 225, 21) // "on_NewPortBox_clicked"

    },
    "MainWindow\0on_OpenSerialButton_clicked\0"
    "\0ReadData\0ConvertChartoHex\0ch\0"
    "ConvertHexToChar\0ParseFrame\0QByteArray&\0"
    "msg\0SenRequestData\0Cmd\0Data\0CalFCS\0"
    "data\0StringToHex\0str\0senddata\0"
    "on_FileButton_clicked\0on_NewPortBox_activated\0"
    "arg1\0on_NewPortBox_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x08 /* Private */,
       3,    0,   70,    2, 0x08 /* Private */,
       4,    1,   71,    2, 0x08 /* Private */,
       6,    1,   74,    2, 0x08 /* Private */,
       7,    1,   77,    2, 0x08 /* Private */,
      10,    2,   80,    2, 0x08 /* Private */,
      13,    1,   85,    2, 0x08 /* Private */,
      15,    2,   88,    2, 0x08 /* Private */,
      18,    0,   93,    2, 0x08 /* Private */,
      19,    1,   94,    2, 0x08 /* Private */,
      21,    0,   97,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Char, QMetaType::Char,    5,
    QMetaType::Char, QMetaType::Char,    5,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, QMetaType::Char, QMetaType::QByteArray,   11,   12,
    QMetaType::UChar, 0x80000000 | 8,   14,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 8,   16,   17,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   20,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_OpenSerialButton_clicked(); break;
        case 1: _t->ReadData(); break;
        case 2: { char _r = _t->ConvertChartoHex((*reinterpret_cast< char(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< char*>(_a[0]) = _r; }  break;
        case 3: { char _r = _t->ConvertHexToChar((*reinterpret_cast< char(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< char*>(_a[0]) = _r; }  break;
        case 4: _t->ParseFrame((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 5: _t->SenRequestData((*reinterpret_cast< char(*)>(_a[1])),(*reinterpret_cast< QByteArray(*)>(_a[2]))); break;
        case 6: { unsigned char _r = _t->CalFCS((*reinterpret_cast< QByteArray(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< unsigned char*>(_a[0]) = _r; }  break;
        case 7: _t->StringToHex((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QByteArray(*)>(_a[2]))); break;
        case 8: _t->on_FileButton_clicked(); break;
        case 9: _t->on_NewPortBox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_NewPortBox_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
